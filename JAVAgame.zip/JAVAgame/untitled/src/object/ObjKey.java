package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class ObjKey extends SuperObject
{

    public ObjKey()
    {
        name = "EdibleFlower";

        try
        {
            image = ImageIO.read(getClass().getResourceAsStream("/objects/flower1.png"));
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        solidArea.x=5;
        collision=true;
    }
}
